# KB04｜Agenda 工作表版型規格（Python 產檔依據）

> 📌 用途：常駐 Project Knowledge，作為最後關卡 Python（openpyxl）合成 `YYYYMMDD Agenda #編號` 工作表的版型標準。
> 來源：架構師解析 `Signup Sheet.xlsx` 內 `20261020 Agenda #183`（最近一場、作為版型母本）與 `20261006 Agenda #182`。
> 版本：v0.4（確認回填 Sign up、另存新檔）

---

## 1. 工作表命名與位置

- 名稱：`YYYYMMDD Agenda #編號`（例：`20261117 Agenda #185`），**名稱前後不可有空白**（歷史 ` 20260915 Agenda #181`、` 20260804 Agenda #178` 開頭多了空白）。
- `#編號` 必須與 C4 內文一致（歷史 #178～#181 工作表名稱比內文多 1 號，屬錯誤範例，勿模仿）。
- 位置：插在所有 Agenda 工作表最前面（緊接隱藏範本之後），維持「新→舊」排列。
- 母本：一律複製「最近一場」Agenda 工作表；不可使用三張隱藏範本。

## 2. 欄寬與整體樣式

| 欄 | 寬度 | 內容 |
|---|---|---|
| A | 13.66 | Time（時間型別，格式 `h:mm`，置中） |
| B | 10.16 | Min（**文字格式 `@`**，置中） |
| C | 64.16 | Session（靠左） |
| D | 27.5 | 角色標籤 |
| E | 27.33 | Session Host |

- 字型：Arial 14pt（C1 俱樂部名稱 20pt），版面直向（portrait）。
- 表頭列與三個區段標題列、`Meeting Adjourned` 列：底色 `FFF2CC`（淺黃），置中，A:E 合併。

## 3. 標題區（第 1～7 列，必改欄位以 ✏️ 標示）

| 儲存格 | 內容格式 | 範例（#183） |
|---|---|---|
| C1（C:D 合併） | 俱樂部名稱，沿用 | `Claude Toastmasters` |
| ✏️ C2（C:D 合併） | `Date & Time:  YYYY/MM/DD 7:00-9:00 pm`（Date & Time: 後兩個空白） | `Date & Time:  2026/10/20 7:00-9:00 pm` |
| C3（C:D 合併） | 地址，沿用 | Venue: No. 242, Sec. 2, Wenhua Rd.… |
| ✏️ C4（C:D 合併） | `Meeting: #編號 (meets every 1st/3rd Tuesday)` | `Meeting: #183 (meets every 1st/3rd Tuesday)` |
| ✏️ C6（C:D 合併） | `Meeting Theme: ` ＋ Sign up 第 5 列；無則留 `Meeting Theme: ` | `Meeting Theme: The best Investment` |
| ✏️ C7（C:D 合併） | `Theme Question: ` ＋ Sign up 第 6 列；無則留 `Theme Question: ` | — |
| E6、E7 | Admission／Club No，沿用 | — |
| A1 起 | Logo 圖片（錨點 A1） | — |

> 歷史錯誤範例：` 20260804 Agenda #178` 的 C2 仍是 `2026/10/20`（舊日期忘了改），正是 SOP 警告的情況。

## 4. 節目區（第 8 列起，列數隨 Speaker 數與 News Master 變動）

- 第 8 列表頭：`Time | Min | Session(C:D 合併) | Session Host`。
- 行順序、角色標籤、B 欄數值與時間公式：依 `KB02_角色與Agenda行對照表.md`。
- **B 欄寫入規則**：一律寫入**字串**並設定 `number_format = '@'`。歷史成品 B 欄已被 Excel 轉成日期（如 `4-5` 變成 `2026-04-05`、`2-3` 變成 `2025-02-03`），這是**錯誤示範**；純數字（`1`、`5`、`10`）也以文字寫入。
- A 欄寫入 `datetime.time` 物件，格式 `h:mm`。
- `Group Photo & Intermission` 列 C:E 合併；三個區段標題列 A:E 合併。

## 5. 頁尾區（Meeting Adjourned 之後）

依序：`Toastmasters Club Mission` → `Officer Team`（7 列，沿用上一場）→ `The Speech Objectives`（✏️ 每場重產）→ `Toastmasters Pathway`（6 列縮寫，沿用）→ `Resources`（QR Code 圖片列，沿用）。

- **The Speech Objectives**：每個「不重複」專案 1 列；A:B 合併寫專案名稱，C:E 合併寫英文 Purpose（來源 `KB03` 的 Purpose 欄，網站原文）。項數依專案數伸縮。
  - 選修名稱未知的專案與 Workshop 專案：保留該列，A:B 名稱與 C:E Purpose 都留白，由 VPE 日後補上。
  - 歷史錯誤範例：#182 把 `Evaluation and Feedback` 列了兩次（違反「相同專案只列一次」）。
- 頁尾含多張圖片（Officer 區附近 1 張、Resources 列 4 張 QR Code，以及 #183 的 A34:E47 合併區塊），重建工作表時必須保留。

## 6. Python 產檔技術注意事項（⚠️ 重要）

| 風險 | 說明 | 建議作法 |
|---|---|---|
| 圖片遺失 | `openpyxl` 的 `copy_worksheet()` **不會複製圖片**（Logo、QR Code） | 從母本工作表讀出 `_images`，依原錨點重新加入新工作表 |
| 插入或刪除列 | `insert_rows()` 不會移動合併儲存格與圖片錨點 | 節目區與頁尾**依規格逐列重建**，不要用插入列的方式 |
| 活頁簿既有物件遺失 | `Sign up` 工作表 A1 有「Threaded comment」，活頁簿另有 358 筆 Document Tasks，openpyxl 存檔後會遺失或降級為一般註解 | ✅ 學員確認：另存新檔 `Signup Sheet_#編號.xlsx`，**原檔不動** |
| B 欄變日期 | 未設文字格式會被 Excel 解讀為日期 | 一律 `cell.number_format='@'` 並寫入 str |
| 寫回 Sign up | 排定結果寫回 Sign up 目標場次欄 | ✅ 學員確認：**要回填**；已有姓名者保留不動，不設的角色填 `X` |
