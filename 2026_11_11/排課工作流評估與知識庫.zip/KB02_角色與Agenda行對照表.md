# KB02｜角色與 Agenda 行對照表＋時間推算表

> 📌 用途：常駐 Project Knowledge。SOP 步驟 5 提到「依下方『角色對照表』」，但原 docx **沒有附上此表**。本檔以 **`Sign up` 工作表的角色列序（A 欄第 4～32 列）為對照依據**（學員已確認），Agenda 行的先後順序則沿用最近一場 Agenda（#183）。
> 版本：v0.5（清除所有待確認標記）

---

## 1. Sign up 列 → Agenda 行對照

| Sign up 列（A 欄） | Agenda C 欄 Session 文字 | Agenda D 欄角色標籤 | E 欄 Session Host 寫法 |
|---|---|---|---|
| （固定幹部，取自上一場 Officer Team：Sergeant At Arms） | `Call the Meeting to Order` | `S.A.A` | 全名 |
| （固定幹部：President） | `Open Remark / Guest Introduction` | `President` | 全名 |
| 第 4 列 `TME` | `Toastmaster of the Evening Opening` | `TME` | 全名 |
| 第 8 列 `Timer` | `Timer's Introduction` | `Timer` | 全名 |
| 第 9 列 `Ah Counter` | `Ah Counter's Introduction` | `Ah Counter` | 全名 |
| 第 10 列 `Language Evaluator` | `Word of the Day` | `Language Evaluator` | 全名 |
| 第 11 列 `News Master`（`X` 則整行不列） | `News Master` | `News Master` | 全名 |
| 第 17～22 列 `Speaker#n` | `Speech #n: (PM 4-2)`（不寫題目） | `Speaker #n` | 全名 |
| — | `Group Photo & Intermission` | （C:E 合併，無角色） | — |
| 第 24 列 `Table Topics Master` | `Table Topic Session` | `Table Topic Master` | 全名 |
| 第 26 列 `General Evaluator` | `General Evaluation Opening` | `General Evaluator` | 全名 |
| 第 27～32 列 `Evaluator n` | `Speech Evaluator #n: L4P2 - <專案名稱>` | `Individual Evaluator #n` | 全名 |
| 第 10 列 `Language Evaluator` | `Language Evaluation` | `Language Evaluator` | 全名 |
| 第 8＋9 列 | `Timer & Ah Counter Report` | `Timer & Ah Counter` | `名/ 名`（例：`Tim/ Rachel`，取名字第一個字） |
| 第 26 列 `General Evaluator` | `General Evaluation` | `General Evaluator` | 全名 |
| （President） | `Member Achievement & Recognition` | `President` | 全名 |
| （President） | `Guest feedback & Announcement` | `President` | 全名 |
| — | `Meeting Adjourned`（A:E 合併） | — | — |
| 第 12 列 `Joke Master` | 近期皆 `X`，不列 | — | — |
| 第 13～15 列 Variety Session Host／Listening Master／Vote Counter | 學員確認：不設、不列 | — | — |

- Evaluator #n **對應 Speaker #n**：`Speech Evaluator #n` 後面寫的是 Speaker #n 的 Project 代碼與專案名稱（例：`Speech Evaluator #1: L1P1 - Ice Breaker`）。
- 選修專案名稱未知時，名稱留白：`Speech Evaluator #2: L4P2 - `（日後補上）。
- Workshop 專案：Speech 行寫 `Speech #n: (EH )`，Evaluator 行寫 `Speech Evaluator #n: `，皆由 VPE 手動補上；B 欄仍為 `10-15`。
- 遠端參與者加註 `(Online)`：Sign up 有註記才加（歷史出現 `Michael Yu (Online)`）。

## 2. Agenda 行順序（依 #183 實際順序）

```
[標題區 C1～E7]
第 8 列  表頭：Time | Min | Session | (C:D 合併) | Session Host
         Call the Meeting to Order
         Open Remark / Guest Introduction
         Toastmaster of the Evening Opening
         Timer's Introduction
         Ah Counter's Introduction
         Word of the Day
         News Master                      ← 有排才列
[標題列] Prepared Speech.  Timer Cards: Green: 5 min; Yellow: 6 min; Red: 7 min
         Speech #1 … Speech #n            ← 依 Speaker 人數
         Group Photo & Intermission
[標題列] Table Topic Speech.  Timer Cards: Green: 1 min; Yellow: 1.5 min; Red: 2 min
         Table Topic Session
[標題列] Evaluation.  Timer Cards: Green: 2 min; Yellow: 2.5 min; Red: 3 min
         General Evaluation Opening
         Speech Evaluator #1 … #n         ← 人數 = Speaker 人數
         Language Evaluation
         Timer & Ah Counter Report
         General Evaluation
         Member Achievement & Recognition
         Guest feedback & Announcement
         Meeting Adjourned
[頁尾] Club Mission → Officer Team → The Speech Objectives → Toastmasters Pathway → Resources
```

## 3. 表定時間與時間推算表（SOP 原表）

| 節目 | 表定時間（B 欄，文字格式） | 下一節目要加幾分鐘 |
|---|---|---|
| Call the Meeting to Order | `1` | 2 |
| Open Remark / Guest Introduction | `5` | 6 |
| Toastmaster of the Evening Opening | `3` | 4 |
| Timer's Introduction / Ah Counter's Introduction / Word of the Day | `2` | 3 |
| News Master（有排才列） | `4-5` | 6 |
| Speech：Ice Breaker（L1P1） | `4-6` | 7 |
| Speech：一般專案 | `5-7` | 8 |
| Speech：Workshop | `10-15` | 16 |
| Group Photo & Intermission | `10` | 11 |
| Table Topic Session | `15` | 16 |
| General Evaluation Opening、每位 Speech Evaluator | `2-3` | 4 |
| Language Evaluation、General Evaluation | `4-5` | 6 |
| Timer & Ah Counter Report、Member Achievement & Recognition | `3` | 4 |
| Guest feedback & Announcement（接著 Meeting Adjourned） | `10` | 11 |

**公式**：第一行 19:10；`下一行開始 = 本行開始 + 表定上限 + 1`；三個標題列不佔時間；`Meeting Adjourned` 不寫時間（歷史成品 A 欄無值）。

**驗算基準（#183 實績，3 位 Speaker＋News Master）**：
19:10 → 19:12 → 19:18 → 19:22 → 19:25 → 19:28 → 19:31(News) → 19:37 → 19:44 → 19:52 → 20:00(Photo) → 20:11(TT) → 20:27(GE Open) → 20:31 → 20:35 → 20:39 → 20:43(Lang) → 20:49(T&A) → 20:53(GE) → 20:59 → 21:03 → 結束 21:14 ✅ 與 SOP 一致。

- 超過 21:15：記下提醒，不刪節目。
- `Prepared Speech` 標題列的 Timer Cards 文字固定寫 5／6／7 min，即使本場有 Ice Breaker 或 Workshop 也不改（沿用 #183 實績，日後可調整）。
