# KB03｜Pathways 縮寫、專案名稱與 Purpose 對照表

> 📌 用途：常駐 Project Knowledge，取代每次手動上網查 Purpose，供「Speech Evaluator #n: LxPy - 專案名稱」與頁尾「The Speech Objectives」使用。
> 來源：District 205 Pathways 網站 https://d205tm.org/paths-and-projects （2026/11/11 由 AI 下載網頁原始碼後，以程式逐字擷取，**Purpose 皆為網站原文**）＋ 歷史 Agenda 頁尾。
> 版本：v0.4（Purpose 由 AI 自動擷取補齊，G3 結案）
>
> ⚠️ 使用規則：
> 1. **Level 3 以上的「選修（Elective）」專案沒有固定編號**，`L3P2`、`L4P2` 等代碼無法單靠代碼查出名稱 → **預設留白，由 VPE 詢問後補上**（見 KB01 第 4 節）。名稱補上後，再到本表第 6 節查 Purpose。
> 2. Workshop 專案：代碼與名稱留白，由 VPE 手動補上。
> 3. 頁尾 Objectives 預設使用「Purpose」欄（SOP 規定）。另附「簡介」欄：#183 歷史成品實際貼的是簡介而非 Purpose（例：Ice Breaker 寫 *This foundational project is designed…*），兩者擇一請見評估報告 G3 附註。
> 4. 網站原文中的小瑕疵已**照原文保留**於 Purpose（例：`wellorganized` 缺連字號、EH L5P1 句首缺 `The`）；專案名稱的錯字已更正（網站寫 `Intellegence`→Intelligence、`Buildng`→Building、`Bog`→Blog）。

---

## 1. Path 縮寫表（與 Agenda 頁尾「Toastmasters Pathway」一致）

| 縮寫 | 英文 Path | 中文 |
|---|---|---|
| DL | Dynamic Leadership | 活力領導 |
| EH | Engaging Humor | 善用幽默 |
| MS | Motivational Strategies | 激勵策略 |
| PM | Presentation Mastery | 精通演講 |
| PI | Persuasive Influence | 說服影響 |
| VC | Visionary Communication | 願景溝通 |

## 2. Project 代碼轉換規則

| Members 表內寫法 | Speech 行寫法 | Evaluator 行代碼 |
|---|---|---|
| `L4P2` | `4-2` | `L4P2` |
| `L1P4-1`、`L1P4-2`、`L1P4` | `1-4` | `L1P4` |
| `Ice breaker` | `1-1`（⚠️依歷史推定） | `L1P1` |
| `L3 Workshop`、`L4 Workshop 1/2` | 留白：`(EH )`（VPE 手動補） | 留白（VPE 手動補） |
| L3 以上選修代碼（如 `L3P2`、`L4P2`） | 照常轉換（`4-2`） | 代碼照寫，名稱留白：`L4P2 - ` |

## 3. 各 Path 必修專案（代碼可直接對應）

| Path | L1P1 | L1P2 | L1P3 | L1P4 |
|---|---|---|---|---|
| DL | Ice Breaker | Writing a Speech with Purpose | Introduction to Vocal Variety and Body Language | Evaluation and Feedback |
| EH | Ice Breaker | Writing a Speech with Purpose | Introduction to Vocal Variety and Body Language | Evaluation and Feedback |
| MS | Ice Breaker | Writing a Speech with Purpose | Introduction to Vocal Variety and Body Language | Evaluation and Feedback |
| PI | Ice Breaker | Writing a Speech with Purpose | Introduction to Vocal Variety and Body Language | Evaluation and Feedback |
| PM | Ice Breaker | Writing a Speech with Purpose | Introduction to Vocal Variety and Body Language | Evaluation and Feedback |
| VC | Ice Breaker | Writing a Speech with Purpose | Introduction to Vocal Variety and Body Language | Evaluation and Feedback |

**Level 2（必修）**

| Path | L2P1 | L2P2 | L2P3 |
|---|---|---|---|
| DL | Understanding Your Leadership Style | Understanding Your Communication Style | Introduction to Toastmasters Mentoring |
| EH | Know Your Sense of Humor | Connect with Your Audience | Introduction to Toastmasters Mentoring |
| MS | Understanding Your Communication Style | Active Listening | Introduction to Toastmasters Mentoring |
| PI | Understanding Your Leadership Style | Active Listening | Introduction to Toastmasters Mentoring |
| PM | Understanding Your Communication Style | Effective Body Language | Introduction to Toastmasters Mentoring |
| VC | Understanding Your Leadership Style | Understanding Your Communication Style | Introduction to Toastmasters Mentoring |

> ⚠️ 網站在每條 Path 的 Level 2 最後，都重複出現一段 *Evaluation and Feedback* 內容，但**沒有專案標題**。是否算 `L2P4`，網站沒有交代；若會員紀錄出現 `L2P4`，請以 VPE 確認為準。

**Level 3～5（必修）**

| Path | L3 必修 | L4 必修 | L5 必修 | L5 必修 |
|---|---|---|---|---|
| DL | Negotiating the Best Outcome | Manage Change | Lead in Any Situation | Reflect on Your Path |
| EH | Engage Your Audience with Humor | The Power of Humor in an Impromptu Speech | Deliver Your Message with Humor | Reflect on Your Path |
| MS | Understanding Your Emotional Intelligence | Motivate Others | Team Building | Reflect on Your Path |
| PI | Understanding Conflict Resolution | Leading in Difficult Situations | High Performance Leadership | Reflect on Your Path |
| PM | Persuasive Speaking | Managing a Difficult Audience | Prepare to Speak Professionally | Reflect on Your Path |
| VC | Negotiate the Best Outcome | Communicate Change | Develop Your Vision | Reflect on Your Path |

> ⚠️ 網站沒有編號。依俱樂部慣例，`L3P1`、`L4P1` 推定為該 Level 的必修專案；`L3P2` 以後、`L4P2` 以後推定為選修（例：#182 Helen 的 `PM L3P1` 對應 Persuasive Speaking，符合推定）。Level 5 兩個必修與一個選修對應 `L5P1`～`L5P3` 的順序，請 VPE 確認。

## 4. 必修專案 Purpose 與簡介（網站原文）

| 專案名稱 | Purpose（Objectives 預設使用） | 簡介（#183 歷史成品的寫法） |
|---|---|---|
| Ice Breaker | The purpose of this project is to introduce yourself to the club and learn the basic structure of a public speech. | This foundational project is designed to introduce you to your club and the skills you need to begin your Toastmasters journey. |
| Writing a Speech with Purpose | The purpose of this project is to learn or review basic methods for writing a speech and to present a wellorganized speech on any topic. | This project addresses topic selection strategies, how to define the purpose of your speech, and methods for producing a well-organized speech. |
| Introduction to Vocal Variety and Body Language | The purpose of this project is to practice using vocal variety or body language to enhance a speech. | This project focuses on the fundamentals of delivering a speech—vocal variety and body language. |
| Evaluation and Feedback | The purpose of this project is to present a speech on any topic, receive feedback, and apply the feedback to a second speech. | This project addresses the skills needed to give and receive feedback. You will learn about giving, receiving, and applying feedback. |
| Understanding Your Leadership Style | The purpose of this project is to identify your primary leadership style or styles. | This project is designed to introduce the different styles of leadership and help you identify your preferred style. |
| Understanding Your Communication Style | The purpose of this project is to learn about different communication styles and identify your primary style. | This project focuses on recognizing your preferred communication style and understanding how your style impacts your interactions with others. |
| Introduction to Toastmasters Mentoring | The purpose of this project is to clearly define how Toastmasters envisions mentoring. | This project introduces the value of mentorship and the Toastmasters view of mentors and protégés. |
| Negotiating the Best Outcome | The purpose of this project is to learn about different types of negotiation and the strategies that can be used when negotiating. | This project focuses on identifying negotiation styles, engaging in mutually beneficial discussions, and finding and building common ground. |
| Manage Change | The purpose of this project is to practice developing a change management plan. | This project focuses on how to plan for change, develop a communication plan, and identify obstacles to success. |
| Lead in Any Situation | The purpose of this project is to apply the skills needed to successfully lead in a volunteer or other organization. | This project focuses on leadership and recognizing the need to adapt your style based on the situation and the people you lead. |
| Reflect on Your Path | The purpose of this project is to reflect on your growth during the completion of an entire path. | Note: While this project appears in Toastmasters International material as being a Level 5 project, it is accessed within Base Camp following the level under Path Completion . |
| Know Your Sense of Humor | The purpose of this project is to begin developing a collection of humorous stories and to present a speech that includes humor. | This project focuses on understanding what makes you laugh and how to share that with an audience. |
| Connect with Your Audience | The purpose of this project is to practice the skills needed to connect with an unfamiliar audience. | This project focuses on different audience types and how to address them effectively. |
| Engage Your Audience with Humor | The purpose of this project is for you to determine your style of humor and apply it to a speech that centers around a central message. | This project focuses on using humor to enhance the message you deliver in your speech. |
| The Power of Humor in an Impromptu Speech | The purpose of this project is for you to develop your method for giving impromptu speeches and practice adapting rehearsed stories during a presentation. | This project focuses on developing strategies for adding humor to any speech, especially impromptu speeches. |
| Deliver Your Message with Humor | purpose of this project is to practice developing and presenting a longer humorous speech. | This project focuses on creating a keynote-length speech that effectively delivers a message and humor to an audience. |
| Active Listening | The purpose of this project is to demonstrate your ability to listen to what others say. | This project covers the difference between hearing and listening, and steps for exploring the ways listening helps build strong, lasting connections. |
| Understanding Your Emotional Intelligence | The purpose of this project is to cultivate an understanding of how your emotions impact your relationships. It is also designed to help you identify how others’ emotions impact your emotional state. | This project addresses elements of emotional intelligence. It is designed to help you understand your own emotions and the emotions of others. |
| Motivate Others | The purpose of this project is to practice the skills needed to motivate team members through the completion of a project. | This project focuses on how people are motivated. It is designed to help you build your leadership skills by effectively motivating team members. |
| Team Building | The purpose of this project is to practice the skills needed to build a cohesive team and host an event. | This project addresses the benefits of team building. It is designed to help you build a sense of collaboration and trust within a team completing a project. |
| Understanding Conflict Resolution | The purpose of this project is to develop or enhance your understanding of the steps and strategies to address conflict. | This project is designed to introduce conflict resolution strategies and provide an opportunity to resolve a conflict scenario within an interactive activity. |
| Leading in Difficult Situations | The purpose of this project is to practice strategies for adjusting to unexpected changes to a finalized plan. | This project focuses on the fundamentals of managing challenges, analyzing difficult situations and identifying best strategies for overcoming adversity. |
| High Performance Leadership | The purpose of this project is to apply your leadership and planning knowledge to develop a project plan, organize a guidance committee, and implement your plan with the help of a team. | The focus of this project is to design and complete a project with well-defined goals, lead a team and be accountable to a guidance committee. |
| Effective Body Language | The purpose of this project is to deliver a speech with awareness of your intentional and unintentional body language, as well as to learn, practice, and refine how you use nonverbal communication when delivering a speech. | This project focuses on how to recognize body language used when speaking publicly and how to use gestures to enhance speech content. |
| Persuasive Speaking | The purpose of this project is to understand the types of persuasive speeches and deliver a persuasive speech at a club meeting. | This project focuses on helping you to develop and support a viewpoint, and identify the most appropriate type of persuasive speech for your topic. |
| Managing a Difficult Audience | The purpose of this project is to practice the skills needed to address audience challenges when you present outside of your Toastmasters club. | This project covers common behaviors of difficult audience members and how to address each behavior in a calm, effective and professional way. |
| Prepare to Speak Professionally | The purpose of this project is to practice developing and presenting a longer speech. | This project is designed to help you define the attributes of professional speakers and apply that understanding to your skills as a speaker. |
| Negotiate the Best Outcome | The purpose of this project is to learn about different types of negotiation and the strategies that can be used when negotiating. | This project focuses on identifying negotiation styles, engaging in mutually beneficial discussions, and finding and building common ground. |
| Communicate Change | The purpose of this project is to practice the skills needed to effectively communicate change to a group or organization. | This project focuses on creating a communication plan by gathering evidence to support the need for change and communicating change with your audience. |
| Develop Your Vision | The purpose of this project is to develop a detailed vision for your personal life, professional life, or an organization. | This project focuses on developing a vision for your work or personal life. |

## 5. Level 3 選修（選 2）｜Purpose 與簡介（網站原文）

| 專案名稱 | 不可選的 Path（已是該 Path 必修） | Purpose | 簡介 |
|---|---|---|---|
| Deliver Social Speeches | — | The purpose of this project is to practice delivering social speeches in front of your club members. | This project addresses the skills needed to compose a speech for a social occasion including a toast, a eulogy, an acceptance speech, and a speech praising an individual or group. |
| Using Presentation Software | — | The purpose of this project is to introduce or review basic presentation software strategies for creating and using slides to support or enhance a speech. | This project addresses the use of presentation software—from identifying topics that benefit from the use of technology to effective slide design and presentation. |
| Connect with Storytelling | — | The purpose of this project is to practice using a story within a speech or giving a speech that is a story. | This project addresses storytelling techniques and descriptive skills to help make every speech relatable and interesting. |
| Creating Effective Visual Aids | — | The purpose of this project is to practice selecting and using a variety of visual aids during a speech. | This project addresses effective methods for choosing the best visual aid for your presentation along with the creation and use of each type. |
| Using Descriptive Language | — | The purpose of this project is to practice writing a speech with an emphasis on adding language to increase interest and impact. | This project addresses the difference between literal and figurative language along with how to determine when to use each to create vivid descriptions. |
| Connect with Your Audience | EH | The purpose of this project is to practice the skills needed to connect with an unfamiliar audience. | This project focuses on different audience types and how to address them effectively. |
| Make Connections through Networking | — | The purpose of this project is to develop and practice a personal strategy for building connections through networking. | This project focuses on how to network effectively and understanding the importance of being a professional ally to people in your network. |
| Focus on the Positive | — | The purpose of this project is to practice being aware of your thoughts and feelings, as well as the impact of your responses on others. | This project addresses strategies for improving your personal interactions by understanding the impact of your attitudes and thoughts on daily interactions. |
| Inspire Your Audience | — | The purpose of this project is to practice writing and delivering a speech that inspires others. | This project addresses how to present a speech in an enthusiastic and inspiring fashion to establish a strong rapport with your audience. |
| Prepare for an Interview | — | The purpose of this project is to practice the skills needed to present yourself well in an interview. | This project addresses the skills you need to identify and speak about personal strengths and present yourself well in an interview of any type. |
| Understanding Vocal Variety | — | The purpose of this project is to practice using vocal variety to enhance a speech. | This project addresses the importance of vocal variety when giving a speech and provides activities to develop and nurture its use. |
| Effective Body Language | PM | The purpose of this project is to deliver a speech with awareness of your intentional and unintentional body language, as well as to learn, practice, and refine how you use nonverbal communication when delivering a speech. | This project focuses on how to recognize body language used when speaking publicly and how to use gestures to enhance speech content. |
| Active Listening | MS, PI | The purpose of this project is to demonstrate your ability to listen to what others say. | This project covers the difference between hearing and listening, and steps for exploring the ways listening helps build strong, lasting connections. |
| Know Your Sense of Humor | EH | The purpose of this project is to begin developing a collection of humorous stories and to present a speech that includes humor. | This project focuses on understanding what makes you laugh and how to share that with an audience. |
| Research and Presenting | — | The purpose of this project is to learn or review basic research methods and present a well-organized, well-researched speech on any topic. | This project addresses topic selection strategies, suggestions for research and methods for producing a well-organized speech. |

## 6. Level 4 選修（選 1）｜Purpose 與簡介（網站原文）

| 專案名稱 | 不可選的 Path（已是該 Path 必修） | Purpose | 簡介 |
|---|---|---|---|
| Create a Podcast | — | The purpose of this project is to introduce you to the skills needed to organize and present a podcast. | This project addresses the skills you need to develop a podcast, create interesting content and organize a cohesive program. You will learn how to record and upload it to the internet. |
| Building a Social Media Presence | — | The purpose of this project is to apply your understanding of social media to enhance an established or new social media presence. | This project addresses how best to use different types of online communication. You will create and maintain an online profile to promote yourself or an organization. |
| Managing a Difficult Audience | PM | The purpose of this project is to practice the skills needed to address audience challenges when you present outside of your Toastmasters club. | This project covers common behaviors of difficult audience members and how to address each behavior in a calm, effective and professional way. |
| Write a Compelling Blog | — | The purpose of this project is to review or introduce the skills needed to write and maintain a blog. | This project addresses the basics of developing a compelling blog and successfully engaging a readership. |
| Manage Online Meetings | — | The purpose of this project is to practice facilitating an online meeting or leading a webinar. | This project addresses how to effectively conduct online meetings and webinars, prepare and organize necessary visual aids, and lead with confidence. |
| Question and Answer Session | — | The purpose of this project is to learn about and practice facilitating a question-and-answer session. | This project addresses how to prepare to answer questions and provide information clearly, concisely and with confidence. |
| Public Relations Strategies | — | The purpose of this project is to practice the skills needed to effectively use public relations strategies for any group or situation . | This project focuses on how to promote awareness of an organization, formulate a public relations strategy and use various public relations tactics. |
| Manage Projects Successfully | — | The purpose of this project is to practice developing a plan, building a team, and fulfilling the plan with the help of your team. | This project focuses on skills needed to effectively manage a project, develop rapport with stakeholders, and cultivate strong relationships with a team. |

## 7. Level 5 選修（選 1）｜Purpose 與簡介（網站原文）

| 專案名稱 | 不可選的 Path（已是該 Path 必修） | Purpose | 簡介 |
|---|---|---|---|
| Lessons Learned | — | The purpose of this project is to learn about and apply the skills needed to run a lessons learned meeting during a project or after its completion. | This project addresses how to identify the discussion points of a large group meeting, encourage a culture of contribution and voicing opinions, and facilitate productive discussion that yields results. |
| Moderate a Panel Discussion | — | The purpose of this project is to apply your skills as a public speaker and leader to facilitate a panel discussion. | This project addresses the skills needed to successfully moderate a panel discussion and how to be an effective participant on a panel. |
| Ethical Leadership | — | The purpose of this project is to develop a clear understanding of your own ethical framework and create an opportunity for others to hear about and discuss ethics in your organization or community. | This project addresses the importance of recognizing the effect of decisions that impact ethics, best practices for making ethical decisions and developing an ethical framework. |
| Leading in Your Volunteer Organization | — | The purpose of this project is to apply the skills needed to successfully lead in a volunteer organization. | This project focuses on the skills required to lead in a volunteer organization and the importance of recognition and reward in motivating volunteers. |
| Prepare to Speak Professionally | PM | The purpose of this project is to practice developing and presenting a longer speech. | This project is designed to help you define the attributes of professional speakers and apply that understanding to your own skills as a speaker. |
| High Performance Leadership | PI | The purpose of this project is to apply your leadership and planning knowledge to develop a project plan, organize a guidance committee, and implement your plan with the help of a team. | The focus of this project is to design and complete a project with well-defined goals, lead a team and be accountable to a guidance committee. |

> 歷史實例：#183 Judy Liang 的 `DL L3P3` 在 Agenda 寫成 `Using Presentation Software`，證明選修代碼對應的名稱是**會員個人選擇**。VPE 問到名稱後，直接到上表查 Purpose 即可。
